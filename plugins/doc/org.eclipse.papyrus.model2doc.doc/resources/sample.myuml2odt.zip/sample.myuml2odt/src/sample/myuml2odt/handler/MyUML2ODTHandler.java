/*******************************************************************************
 * Copyright (c) 2018 CEA LIST.
 * All rights reserved.
 * This code is the property of CEA LIST, this use is subject to specific 
 * agreement with the CEA LIST.
 * Contributors:
 *      CEA LIST - initial API and implementation
 *******************************************************************************/
package sample.myuml2odt.handler;

import java.io.File;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.runtime.Path;
import org.eclipse.uml2.uml.Package;

import com.cea.papyrus.model2doc.core.config.GeneratorConfig;
import com.cea.papyrus.model2doc.core.config.GeneratorConfigFactory;
import com.cea.papyrus.model2doc.core.service.TemplateResourceService;
import com.cea.papyrus.model2doc.core.transcriber.Transcriber;
import com.cea.papyrus.model2doc.core.transcription.Transcription;
import com.cea.papyrus.model2doc.documentview.ui.menu.handler.CreateDocumentViewEditorHandler;
import com.cea.papyrus.model2doc.odt.transcription.ODTTranscriptionFactory;

import sample.myuml2odt.Activator;
import sample.myuml2odt.template.MyUMLTemplate;
import sample.myuml2odt.transcriber.MyUMLTranscriber;

/**
 * Handler class for generating ODT file from UML model.
 */
public class MyUML2ODTHandler extends CreateDocumentViewEditorHandler {
	
	private String generatedDocumentFileURI;
	
	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		// never used
		return null;
	}
	
	@Override
	public boolean generateDocument(String name) {
		// instance an object of MyUMLTemplate (see Step 2)
		TemplateResourceService myUMLTemplate =  new MyUMLTemplate();
		
		// get project folder from the select element in the UML model
		String projectFolder = getWorkspaceResourceService().calculateProjectFolder(getSelection());
		
		/*
		 * set generator configuration 
		 */
		GeneratorConfig generatorConfig = GeneratorConfigFactory.INSTANCE.getDefaultGeneratorConfig();
		generatorConfig.setDocumentName(name);
		generatorConfig.setOutputFolder(projectFolder);
		generatorConfig.setProject(projectFolder);
		generatorConfig.setTemplateStyleFileURI(myUMLTemplate.getTemplateURLFromPlugIn());
		
		try {
			
			// get ODT transcription 
			Transcription odtTranscription = ODTTranscriptionFactory.INSTANCE.getDefaultODTTranscription(null, generatorConfig);
			
			// instance an object of MyUMLTranscriber(select element in the UML Model, transcription)
			Transcriber myUMLTranscriber = new MyUMLTranscriber((Package) getSelection(), odtTranscription);
			// run transcriber
			myUMLTranscriber.transcribe();
			
			/*
			 * set URI of generated document file
			 */
			StringBuilder uriBuilder = new StringBuilder();
			uriBuilder.append(generatorConfig.getOutputFolder());
			uriBuilder.append(File.separator);
			uriBuilder.append(generatorConfig.getDocumentName());
			uriBuilder.append(".odt"); //$NON-NLS-1$
			
			Path path = new Path (uriBuilder.toString());
			generatedDocumentFileURI =  path.toString();
			
			// refresh Workspace after document generation
			getWorkspaceResourceService().refreshWorkspace(generatorConfig.getProject());
			return true;
		} catch (Exception e) {
			Activator.log.error(e);
			return false;
		}
	}

	@Override
	public String getGeneratedDocumentFileURI() {
		return generatedDocumentFileURI;
	}
}
