package sample.myuml2odt.template;

import com.cea.papyrus.model2doc.core.service.TemplateResourceServiceImpl;

import sample.myuml2odt.Activator;

public class MyUMLTemplate extends TemplateResourceServiceImpl {

	/**
	 * Get template file extensions.
	 * @return
	 */
	@Override
	public String[] getTemplateFileExtensions() {
		return new String [] {"odt", "ott"}; //$NON-NLS-1$ //$NON-NLS-2$
	}

/**
	 * Get plug-in ID who contains the template.
	 * 
	 * @return
	 */
	@Override
	public String getTemplatePlugInID() {
		return Activator.PLUGIN_ID;
	}

	/**
	 * Get template path in plug-in. 
	 * 
	 * @return
	 */
	@Override
	public String getTemplatePathInPlugIn() {
		return "/resources/template/MyUMLTemplate.ott"; //$NON-NLS-1$
	}


}
