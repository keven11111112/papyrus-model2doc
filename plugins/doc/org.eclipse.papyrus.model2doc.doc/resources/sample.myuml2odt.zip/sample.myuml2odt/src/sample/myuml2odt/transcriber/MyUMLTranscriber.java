package sample.myuml2odt.transcriber;

import java.util.ArrayList;
import java.util.List;
import org.eclipse.uml2.uml.Class;
import org.eclipse.uml2.uml.Package;
import org.eclipse.uml2.uml.Type;

import com.cea.papyrus.model2doc.core.transcriber.Transcriber;
import com.cea.papyrus.model2doc.core.transcription.Transcription;

public class MyUMLTranscriber implements Transcriber {

	private Package root = null;

	private Transcription transcription = null;

	private List<Class> classes = new ArrayList<Class>();

	/**
	 *
	 * Constructor.
	 *
	 * @param rootPackage
	 *            the root package
	 * @param transcription
	 *            the object in charge to do the transcription
	 */
	public MyUMLTranscriber(Package rootPackage, Transcription transcription) {
		root = rootPackage;
		this.transcription = transcription;

	}

	/**
	 * Read UML model and transcribe it.
	 */
	@Override
	public void transcribe() {
		// transcribe label of root package how document main title
		transcription.writeDocumentMainTitle(root.getName());

		// transcribe classes directly owned by root package
		transcribeClasses(root);

		// transcribe nested packages owned by root package
		for (Package nestedPackage : root.getNestedPackages()) {
			transcribeNestedPackages(nestedPackage, 1);

		}

		// save transcription
		transcription.save(root.getName());
	}

	/**
	 * Get nested packages and transcribe them.
	 * 
	 * @param owner
	 *            owner package
	 * @param level
	 *            nested package level
	 */
	private void transcribeNestedPackages(Package owner, int level) {
		// transcribe label of owner package how section title
		transcription.writeSectionTitle(owner.getName(), level);

		// transcribe classes directly owned by owner package
		transcribeClasses(owner);

		for (Package nestedPackage : owner.getNestedPackages()) {
			// transcribe nested packages owned by owner package
			transcribeNestedPackages(nestedPackage, level + 1);
		}
	}

	/**
	 * Get classes and transcribe them.
	 * 
	 * @param owner
	 *            owner package
	 */
	private void transcribeClasses(Package owner) {
		// get classes owned by owner package
		for (Type type : owner.getOwnedTypes()) {
			if (type instanceof Class) {
				classes.add((Class) type);
			}
		}

		// transcribe classes
		for (Class clazz : classes) {
			// transcribe label of class how paragraph
			transcription.writeParagraph(clazz.getName(), false);
		}
		
		classes.clear();
	}
}
